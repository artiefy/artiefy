import { useEffect, useState } from 'react';
import { Button } from '../ui/button';
import { Dialog, DialogOverlay, DialogContent, DialogTitle } from '../ui/dialog';

interface StudentsModalProps {
    lessonId: number;
    isOpen: boolean;
    onClose: () => void;
}

interface Student {
    id: string;
    name: string;
    email: string;
    progress: number;
    lastUpdated: string;
}

const StudentsModal: React.FC<StudentsModalProps> = ({ lessonId, isOpen, onClose }) => {
    const [students, setStudents] = useState<Student[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (isOpen) {
            const fetchStudents = async () => {
                try {
                    setLoading(true);
                    const response = await fetch(`/api/super-admin/students?lessonId=${lessonId}`);
                    if (!response.ok) throw new Error('Error al obtener estudiantes');
                    const data = await response.json();
                    setStudents(data);
                } catch (error) {
                    console.error('Error:', error);
                } finally {
                    setLoading(false);
                }
            };
            void fetchStudents();
        }
    }, [lessonId, isOpen]);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogOverlay />
            <DialogContent className="bg-white p-6 rounded-lg shadow-lg">
                <DialogTitle className="text-xl font-bold">Estudiantes en la Clase</DialogTitle>
                {loading ? (
                    <p>Cargando...</p>
                ) : students.length === 0 ? (
                    <p>No hay estudiantes inscritos en esta clase.</p>
                ) : (
                    <table className="w-full mt-4 border-collapse border border-gray-200">
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="border border-gray-200 px-4 py-2">Nombre</th>
                                <th className="border border-gray-200 px-4 py-2">Email</th>
                                <th className="border border-gray-200 px-4 py-2">Progreso</th>
                                <th className="border border-gray-200 px-4 py-2">Última Conexión</th>
                            </tr>
                        </thead>
                        <tbody>
                            {students.map((student) => (
                                <tr key={student.id} className="text-center">
                                    <td className="border border-gray-200 px-4 py-2">{student.name}</td>
                                    <td className="border border-gray-200 px-4 py-2">{student.email}</td>
                                    <td className="border border-gray-200 px-4 py-2">{student.progress}%</td>
                                    <td className="border border-gray-200 px-4 py-2">
                                        {new Date(student.lastUpdated).toLocaleDateString()}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
                <div className="flex justify-end mt-4">
                    <Button onClick={onClose} className="bg-red-500 hover:bg-red-600 text-white">
                        Cerrar
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default StudentsModal;
