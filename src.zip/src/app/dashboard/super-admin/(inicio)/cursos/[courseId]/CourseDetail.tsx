'use client';

import {  useEffect, useState } from 'react';
import { useUser } from '@clerk/nextjs';
import Image from 'next/image';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '~/components/educators/ui/alert-dialog';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from '~/components/educators/ui/breadcrumb';
import { Button } from '~/components/educators/ui/button';
import { Card, CardHeader, CardTitle } from '~/components/educators/ui/card';
import { Label } from '~/components/educators/ui/label';
import LessonsListEducator from '~/components/super-admin/layout/LessonsListSuperAdmin';
import { toast } from '~/hooks/use-toast';

interface Course {
  id: number;
  title: string;
  description: string;
  categoryid: string;
  dificultadid: string;
  modalidadesid: string;
  instructor: string;
  coverImageKey: string;
  createdAt: string;
  requerimientos: string;
}

const CourseDetail = () => {
  useUser();
  const params = useParams();
  const router = useRouter();
  const courseIdUrl = params?.courseId as string | undefined;

  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<string>('#000000');
  const predefinedColors = ['#000000', '#FFFFFF', '#1f2937'];

  // 🔍 Validar courseId antes de convertirlo
  const courseIdNumber = courseIdUrl && !isNaN(Number(courseIdUrl)) ? Number(courseIdUrl) : null;

  useEffect(() => {
    async function fetchCourse() {
      debugger
      if (!courseIdNumber) return;

      try {
        setLoading(true);
        const response = await fetch(`/api/educadores/courses/${courseIdNumber}`);
        if (!response.ok) throw new Error('Curso no encontrado');
        const data = (await response.json()) as Course;
        setCourse(data);
      } catch (error) {
        console.error('Error cargando el curso:', error);
        setError('No se pudo cargar el curso.');
      } finally {
        setLoading(false);
      }
    }
    void fetchCourse();
  }, [courseIdNumber]);

  useEffect(() => {
    const savedColor = localStorage.getItem(`selectedColor_${courseIdNumber}`);
    if (savedColor) setSelectedColor(savedColor);
  }, [courseIdNumber]);

  if (loading) return <div className="text-center text-lg">🔄 Cargando curso...</div>;
  if (error) return <div className="text-center text-red-500">{error}</div>;
  if (!course)
    return (
      <div className="text-center text-gray-500">
        ❌ No se encontró el curso.
      </div>
    );

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/educadores/courses/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Error al eliminar el curso');
      toast({
        title: 'Curso eliminado',
        description: 'El curso se ha eliminado correctamente.',
      });
      router.push('/dashboard/super-admin/cursos');
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: 'Error',
        description: 'No se pudo eliminar el curso.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="bg-background container h-auto w-full rounded-lg p-6">
      {/* 🔗 Navegación Breadcrumb */}
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/dashboard/super-admin" className="hover:text-gray-300">
              Inicio
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/dashboard/super-admin/cursos" className="hover:text-gray-300">
              Lista de cursos
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink className="hover:text-gray-300">
              Detalles del curso
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      {/* 📌 Card de Información del Curso */}
      <Card className="relative z-20 mt-3 overflow-hidden border-none bg-black p-4 text-white">
        <CardHeader className="grid w-full grid-cols-2">
          <CardTitle className="text-2xl font-bold">Curso: {course.title}</CardTitle>
          <div className="ml-9 flex flex-col">
            <Label className="text-white">Seleccione un color:</Label>
            <div className="mt-2 flex space-x-2">
              {predefinedColors.map((color) => (
                <Button
                  key={color}
                  style={{ backgroundColor: color }}
                  className="size-8"
                  onClick={() => setSelectedColor(color)}
                />
              ))}
            </div>
          </div>
        </CardHeader>
        <div className="grid gap-6 md:grid-cols-2">
          <div className="relative aspect-video w-full">
            <Image
              src={`${process.env.NEXT_PUBLIC_AWS_S3_URL}/${course.coverImageKey}`}
              alt={course.title}
              width={300}
              height={100}
              className="mx-auto rounded-lg object-contain"
              priority
              quality={75}
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Información del curso</h2>
            <p className="text-lg">{course.description}</p>
            <p className="text-lg">Instructor: {course.instructor}</p>
            <p className="text-lg">Categoría: {course.categoryid}</p>
            <p className="text-lg">Dificultad: {course.dificultadid}</p>
            <p className="text-lg">Modalidad: {course.modalidadesid}</p>
            <p className="text-lg">Requerimientos: {course.requerimientos}</p>
          </div>
        </div>
		{/* Botones funcionales */}
		<div className="mt-8 grid grid-cols-3 gap-5">
        {/* Botón Visualizar */}
        <Button
          className="bg-green-400 text-white hover:bg-green-500"
        >
          <Link href={`/${course.id}/ver`}>Visualizar curso</Link>
        </Button>

        {/* Botón Editar */}
        <Button
          onClick={() => console.log("Editar curso")}
          className="bg-yellow-500 text-white hover:bg-yellow-600"
        >
          Editar curso
        </Button>

        {/* Botón Eliminar */}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive">Eliminar</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará
                permanentemente el curso <span className="font-bold">{course.title}</span> y
                todos los datos asociados a este.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => handleDelete(course.id.toString())}
                className="border-red-600 bg-red-600 text-white hover:border-red-700 hover:bg-transparent hover:text-red-700"
              >
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      </Card>

      
      {/* 📚 Lista de Lecciones */}
      {courseIdNumber && (
        <LessonsListEducator
          courseId={courseIdNumber}
          selectedColor={selectedColor}
        />
      )}
    </div>
  );
};

export default CourseDetail;
