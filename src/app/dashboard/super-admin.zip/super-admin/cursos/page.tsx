'use client';

import { useEffect, useState } from 'react';
import { useUser } from '@clerk/nextjs';
import { FiPlus } from 'react-icons/fi';

import CourseListTeacher from '~/components/educators/layout/CourseListTeacher';
import { SkeletonCard } from '~/components/educators/layout/SkeletonCard';
import ModalFormCourse from '~/components/educators/modals/ModalFormCourse';
import { getCourses, createCourse, updateCourse, deleteCourse } from '~/server/queries/queries';
import SuperAdminLayout from '../super-admin-layout'; // ✅ Asegura que estás importando el layout correcto

export default function Page() {
  const { user } = useUser();
  const [courses, setCourses] = useState([]);
  const [editingCourse, setEditingCourse] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // ✅ Cargar cursos al cargar la página
  useEffect(() => {
    async function fetchCourses() {
      try {
        const coursesData = await getCourses();
        setCourses(coursesData);
      } catch (error) {
        console.error("Error cargando cursos:", error);
      }
    }
    fetchCourses();
  }, []);

  // ✅ Crear o actualizar curso
  const handleCreateOrUpdateCourse = async (id, title, description, file, categoryid, modalidadesid, dificultadid, requerimientos) => {
    try {
      setUploading(true);
      let coverImageKey = '';

      if (file) {
        const uploadResponse = await fetch('/api/upload', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contentType: file.type, fileSize: file.size }) });

        if (!uploadResponse.ok) throw new Error(`Error al subir imagen: ${uploadResponse.statusText}`);

        const { url, fields } = await uploadResponse.json();
        const formData = new FormData();
        Object.entries(fields).forEach(([key, value]) => formData.append(key, value));
        formData.append('file', file);
        await fetch(url, { method: 'POST', body: formData });

        coverImageKey = fields.key ?? '';
      }

      if (id) {
        await updateCourse(Number(id), { title, description, coverImageKey, categoryid, modalidadesid, dificultadid, requerimientos });
      } else {
        await createCourse({ title, description, coverImageKey, categoryid, modalidadesid, dificultadid, requerimientos });
      }

      setIsModalOpen(false);
      setUploading(false);
      setCourses(await getCourses());
    } catch (error) {
      console.error('Error al procesar el curso:', error);
      setUploading(false);
    }
  };

  return (
    <SuperAdminLayout> {/* ✅ Envolver dentro del layout para que el sidebar no desaparezca */}
      <div className="p-6">
        <header className="flex items-center justify-between rounded-lg bg-gradient-to-r from-[#3AF4EF] to-[#01142B] p-6 text-3xl font-extrabold text-white shadow-lg">
          <h1>Gestión de Cursos</h1>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center rounded-md bg-[#00BDD8] px-6 py-2 font-bold text-white shadow-lg transition-all hover:scale-105 hover:bg-[#0097A7]"
          >
            <FiPlus className="mr-2 size-5" /> Nuevo Curso
          </button>
        </header>

        {courses.length === 0 ? (
          <SkeletonCard />
        ) : (
          <CourseListTeacher courses={courses} onEditCourse={setEditingCourse} onDeleteCourse={() => {}} />
        )}

        {isModalOpen && (
          <ModalFormCourse
            isOpen={isModalOpen}
            onCloseAction={() => setIsModalOpen(false)}
            onSubmitAction={handleCreateOrUpdateCourse}
            uploading={uploading}
            editingCourseId={editingCourse ? editingCourse.id : null}
            title={editingCourse?.title ?? ''}
            description={editingCourse?.description ?? ''}
            requerimientos={editingCourse?.requerimientos ?? ''}
            categoryid={editingCourse?.categoryid ?? 1}
            modalidadesid={editingCourse?.modalidadesid ?? 1}
            dificultadid={editingCourse?.dificultadid ?? 1}
            coverImageKey={editingCourse?.coverImageKey ?? ''}
          />
        )}
      </div>
    </SuperAdminLayout>
  );
}
