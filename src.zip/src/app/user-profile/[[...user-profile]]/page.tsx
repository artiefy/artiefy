import { UserProfile } from '@clerk/nextjs';

const UserProfilePage = () => <UserProfile path="/user-profile" />;

export default UserProfilePage;
