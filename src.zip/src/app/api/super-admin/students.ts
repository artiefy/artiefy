import { eq } from 'drizzle-orm';
import { type NextApiRequest, type NextApiResponse } from 'next';
import { db } from '~/server/db';
import { users, enrollments, userLessonsProgress } from '~/server/db/schema';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'GET') {
        return res.status(405).json({ error: 'Método no permitido' });
    }

    try {
        const { lessonId } = req.query;

        if (!lessonId || isNaN(Number(lessonId))) {
            return res.status(400).json({ error: 'ID de la clase inválido' });
        }

        const students = await db
            .select({
                id: users.id,
                name: users.name,
                email: users.email,
                progress: userLessonsProgress.progress,
                lastUpdated: userLessonsProgress.lastUpdated,
            })
            .from(users)
            .innerJoin(enrollments, eq(users.id, enrollments.userId))
            .innerJoin(userLessonsProgress, eq(users.id, userLessonsProgress.userId))
            .where(eq(userLessonsProgress.lessonId, Number(lessonId)));

        return res.status(200).json(students);
    } catch (error) {
        console.error('Error obteniendo estudiantes:', error);
        return res.status(500).json({ error: 'Error interno del servidor' });
    }
}
