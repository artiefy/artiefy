declare module '@heroicons/react/solid' {
	export * from '@heroicons/react/solid';
}
